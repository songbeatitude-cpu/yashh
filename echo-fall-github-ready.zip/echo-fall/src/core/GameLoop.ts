export type UpdateFn = (fixedDt: number) => void;
export type RenderFn = (alpha: number, frameDt: number) => void;

const FIXED_DT = 1 / 60;
const MAX_FRAME_DT = 0.25; // clamp huge gaps (tab backgrounded, breakpoint, etc.)

/**
 * Decouples simulation from rendering: gameplay/physics update at a fixed
 * timestep (stable NPC/physics behavior regardless of monitor refresh rate),
 * rendering happens once per animation frame with an interpolation alpha.
 */
export class GameLoop {
  private rafHandle: number | null = null;
  private lastTime = 0;
  private accumulator = 0;
  private running = false;

  constructor(private readonly update: UpdateFn, private readonly render: RenderFn) {}

  start(): void {
    if (this.running) return;
    this.running = true;
    this.lastTime = performance.now();
    this.accumulator = 0;
    this.rafHandle = requestAnimationFrame(this.tick);
  }

  stop(): void {
    this.running = false;
    if (this.rafHandle !== null) {
      cancelAnimationFrame(this.rafHandle);
      this.rafHandle = null;
    }
  }

  get isRunning(): boolean {
    return this.running;
  }

  private tick = (now: number): void => {
    if (!this.running) return;

    let frameDt = (now - this.lastTime) / 1000;
    this.lastTime = now;
    frameDt = Math.min(frameDt, MAX_FRAME_DT);

    this.accumulator += frameDt;
    while (this.accumulator >= FIXED_DT) {
      this.update(FIXED_DT);
      this.accumulator -= FIXED_DT;
    }

    const alpha = this.accumulator / FIXED_DT;
    this.render(alpha, frameDt);

    this.rafHandle = requestAnimationFrame(this.tick);
  };
}
