import type { GameEvent, GameEventMap } from '../types';

type Listener<K extends keyof GameEventMap> = (payload: GameEventMap[K]) => void;

/**
 * Central world-event bus (Section 11). Systems subscribe to events instead
 * of holding direct references to each other, so e.g. the mission system,
 * faction system and NPC memory system can all react to
 * PLAYER_DISCOVERED_CLUE without knowing the others exist.
 *
 * Kept as a single instance passed through the app rather than a bare
 * module-level singleton, so it can be swapped/mocked in tests.
 */
export class EventBus {
  private listeners = new Map<keyof GameEventMap, Set<Listener<any>>>();

  on<K extends GameEvent>(event: K, listener: Listener<K>): () => void {
    if (!this.listeners.has(event)) this.listeners.set(event, new Set());
    this.listeners.get(event)!.add(listener);
    return () => this.off(event, listener);
  }

  off<K extends GameEvent>(event: K, listener: Listener<K>): void {
    this.listeners.get(event)?.delete(listener);
  }

  emit<K extends GameEvent>(event: K, payload: GameEventMap[K]): void {
    const set = this.listeners.get(event);
    if (!set || set.size === 0) return;
    // Copy to array: a listener may unsubscribe itself/others mid-emit.
    for (const listener of Array.from(set)) {
      try {
        listener(payload);
      } catch (err) {
        // A single bad subscriber must never break the event bus for
        // everyone else.
        // eslint-disable-next-line no-console
        console.error(`[EventBus] listener for "${String(event)}" threw`, err);
      }
    }
  }

  clear(): void {
    this.listeners.clear();
  }
}
