type LogLevel = 'debug' | 'info' | 'warn' | 'error';

const LEVEL_ORDER: Record<LogLevel, number> = { debug: 0, info: 1, warn: 2, error: 3 };

/**
 * Thin wrapper over console so every system logs consistently and log
 * verbosity can be tuned globally (or silenced) without touching call sites.
 */
export class Logger {
  private static minLevel: LogLevel = import.meta.env.DEV ? 'debug' : 'warn';

  static setMinLevel(level: LogLevel): void {
    Logger.minLevel = level;
  }

  static create(scope: string) {
    return {
      debug: (...args: unknown[]) => Logger.write('debug', scope, args),
      info: (...args: unknown[]) => Logger.write('info', scope, args),
      warn: (...args: unknown[]) => Logger.write('warn', scope, args),
      error: (...args: unknown[]) => Logger.write('error', scope, args)
    };
  }

  private static write(level: LogLevel, scope: string, args: unknown[]): void {
    if (LEVEL_ORDER[level] < LEVEL_ORDER[Logger.minLevel]) return;
    const prefix = `[${scope}]`;
    // eslint-disable-next-line no-console
    console[level === 'debug' ? 'log' : level](prefix, ...args);
  }
}
