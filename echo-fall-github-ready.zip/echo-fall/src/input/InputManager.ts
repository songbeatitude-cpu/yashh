import { InputAction } from '../types';

const DEFAULT_BINDINGS: Record<InputAction, string[]> = {
  [InputAction.MoveForward]: ['KeyW', 'ArrowUp'],
  [InputAction.MoveBack]: ['KeyS', 'ArrowDown'],
  [InputAction.MoveLeft]: ['KeyA', 'ArrowLeft'],
  [InputAction.MoveRight]: ['KeyD', 'ArrowRight'],
  [InputAction.Sprint]: ['ShiftLeft', 'ShiftRight'],
  [InputAction.Crouch]: ['ControlLeft', 'ControlRight', 'KeyC'],
  [InputAction.Jump]: ['Space'],
  [InputAction.Interact]: ['KeyE'],
  [InputAction.Echo]: ['KeyQ'],
  [InputAction.Pause]: ['Escape']
};

/**
 * Owns raw DOM input and exposes a rebindable, action-based API
 * (Section 8/35: architecture must support future gamepad/touch input
 * without gameplay code caring about physical keys).
 */
export class InputManager {
  private bindings: Record<InputAction, string[]>;
  private keysDown = new Set<string>();
  private mouseDeltaX = 0;
  private mouseDeltaY = 0;
  private pointerLocked = false;
  private justPressed = new Set<InputAction>();

  private onKeyDown = (e: KeyboardEvent) => {
    this.keysDown.add(e.code);
  };
  private onKeyUp = (e: KeyboardEvent) => {
    this.keysDown.delete(e.code);
  };
  private onMouseMove = (e: MouseEvent) => {
    if (!this.pointerLocked) return;
    this.mouseDeltaX += e.movementX;
    this.mouseDeltaY += e.movementY;
  };
  private onPointerLockChange = () => {
    this.pointerLocked = document.pointerLockElement === this.canvas;
  };

  constructor(private readonly canvas: HTMLCanvasElement, bindings: Partial<Record<InputAction, string[]>> = {}) {
    this.bindings = { ...DEFAULT_BINDINGS, ...bindings };

    window.addEventListener('keydown', this.trackKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('mousemove', this.onMouseMove);
    document.addEventListener('pointerlockchange', this.onPointerLockChange);
  }

  private trackKeyDown = (e: KeyboardEvent) => {
    if (!this.keysDown.has(e.code)) {
      for (const action of Object.values(InputAction)) {
        if (this.bindings[action].includes(e.code)) this.justPressed.add(action);
      }
    }
    this.onKeyDown(e);
  };

  requestPointerLock(): void {
    if (document.pointerLockElement !== this.canvas) {
      this.canvas.requestPointerLock();
    }
  }

  exitPointerLock(): void {
    if (document.pointerLockElement === this.canvas) {
      document.exitPointerLock();
    }
  }

  get isPointerLocked(): boolean {
    return this.pointerLocked;
  }

  isActionDown(action: InputAction): boolean {
    return this.bindings[action].some((code) => this.keysDown.has(code));
  }

  /** True only on the frame the action transitioned from up -> down. Call
   *  consumeJustPressed() once per fixed update to clear the buffer. */
  wasJustPressed(action: InputAction): boolean {
    return this.justPressed.has(action);
  }

  consumeJustPressed(): void {
    this.justPressed.clear();
  }

  /** Returns and clears accumulated mouse movement since last call. */
  consumeMouseDelta(): { x: number; y: number } {
    const d = { x: this.mouseDeltaX, y: this.mouseDeltaY };
    this.mouseDeltaX = 0;
    this.mouseDeltaY = 0;
    return d;
  }

  rebind(action: InputAction, codes: string[]): void {
    this.bindings[action] = codes;
  }

  dispose(): void {
    window.removeEventListener('keydown', this.trackKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('mousemove', this.onMouseMove);
    document.removeEventListener('pointerlockchange', this.onPointerLockChange);
  }
}
