import { Logger } from '../core/Logger';
import type { SaveData } from '../types';

const log = Logger.create('SaveManager');
const DB_NAME = 'echo-fall';
const DB_VERSION = 1;
const STORE_NAME = 'saves';
const SAVE_FORMAT_VERSION = 1;

/**
 * Meaningful persistent progress (world state, NPC memory, missions,
 * factions, player transform) lives in IndexedDB, per Section 29. Small
 * config/preferences use localStorage instead (see SettingsManager) —
 * we deliberately don't mix the two.
 */
export class SaveManager {
  private dbPromise: Promise<IDBDatabase> | null = null;

  private openDb(): Promise<IDBDatabase> {
    if (this.dbPromise) return this.dbPromise;

    this.dbPromise = new Promise((resolve, reject) => {
      if (!('indexedDB' in window)) {
        reject(new Error('IndexedDB is not available in this browser.'));
        return;
      }
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(STORE_NAME)) {
          db.createObjectStore(STORE_NAME, { keyPath: 'slot' });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error ?? new Error('Failed to open save database.'));
    });

    return this.dbPromise;
  }

  async save(slot: string, data: SaveData): Promise<void> {
    const db = await this.openDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).put({ slot, ...data, version: SAVE_FORMAT_VERSION });
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error ?? new Error('Save transaction failed.'));
    });
    log.info(`Saved slot "${slot}".`);
  }

  async load(slot: string): Promise<SaveData | null> {
    const db = await this.openDb();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const request = tx.objectStore(STORE_NAME).get(slot);
      request.onsuccess = () => resolve((request.result as SaveData) ?? null);
      request.onerror = () => reject(request.error ?? new Error('Load transaction failed.'));
    });
  }

  async hasSave(slot: string): Promise<boolean> {
    try {
      return (await this.load(slot)) !== null;
    } catch (err) {
      log.warn('Could not check for existing save (storage may be unavailable).', err);
      return false;
    }
  }

  async deleteSave(slot: string): Promise<void> {
    const db = await this.openDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      tx.objectStore(STORE_NAME).delete(slot);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error ?? new Error('Delete transaction failed.'));
    });
  }
}
