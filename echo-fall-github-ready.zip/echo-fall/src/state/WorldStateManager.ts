import { EventBus } from '../core/EventBus';
import { GameEvent } from '../types';

/**
 * Single source of truth for everything the world needs to remember
 * (Section 12). NPC memory/relationship *systems* are later-phase work;
 * this manager provides the generic, serializable storage they will write
 * into, keyed so each future system owns its own namespace without the
 * others needing to know its shape.
 */
export class WorldStateManager {
  private store = new Map<string, unknown>();

  constructor(private readonly events: EventBus) {}

  get<T>(key: string): T | undefined {
    return this.store.get(key) as T | undefined;
  }

  set<T>(key: string, value: T): void {
    this.store.set(key, value);
    this.events.emit(GameEvent.WorldStateChanged, { key });
  }

  has(key: string): boolean {
    return this.store.has(key);
  }

  delete(key: string): void {
    this.store.delete(key);
    this.events.emit(GameEvent.WorldStateChanged, { key });
  }

  /** Convenience for "increment reputation / counters" style state. */
  update<T>(key: string, updater: (current: T | undefined) => T): T {
    const next = updater(this.store.get(key) as T | undefined);
    this.set(key, next);
    return next;
  }

  serialize(): Record<string, unknown> {
    return Object.fromEntries(this.store.entries());
  }

  deserialize(data: Record<string, unknown>): void {
    this.store = new Map(Object.entries(data ?? {}));
  }

  reset(): void {
    this.store.clear();
  }
}
