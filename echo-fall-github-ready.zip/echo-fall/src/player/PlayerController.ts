import * as THREE from 'three';
import { InputAction, type IInteractable } from '../types';
import { InputManager } from '../input/InputManager';
import { CameraController } from '../render/CameraController';

const WALK_SPEED = 3.2;
const SPRINT_SPEED = 6.2;
const CROUCH_SPEED = 1.6;
const JUMP_SPEED = 5.5;
const GRAVITY = -16;
const STAND_HEIGHT = 1.7;
const CROUCH_HEIGHT = 1.0;
const MOUSE_SENSITIVITY = 0.0025;
const STAMINA_MAX = 100;
const STAMINA_DRAIN_PER_SEC = 22;
const STAMINA_REGEN_PER_SEC = 14;
const INTERACT_RANGE = 3;

/**
 * Player capsule + movement/camera integration (Section 8). Phase 1 uses a
 * simple ground-plane + collider-radius approximation rather than a full
 * physics engine — enough to move, sprint, crouch and jump around the
 * prototype area. A proper capsule-vs-mesh collider is a documented
 * extension point for when real district geometry exists.
 */
export class PlayerController {
  readonly mesh: THREE.Object3D;

  private velocityY = 0;
  private grounded = true;
  private height = STAND_HEIGHT;
  private crouching = false;

  health = 100;
  stamina = STAMINA_MAX;
  readonly inventory: string[] = []; // foundation only — item system is a later phase

  private nearestInteractable: IInteractable | null = null;
  private interactionCandidates: IInteractable[] = [];

  constructor(
    private readonly input: InputManager,
    private readonly camera: CameraController,
    spawnPosition = new THREE.Vector3(0, 0, 0)
  ) {
    const geometry = new THREE.CapsuleGeometry(0.35, STAND_HEIGHT - 0.7, 4, 8);
    const material = new THREE.MeshStandardMaterial({ color: 0x2fd8c6, roughness: 0.6, metalness: 0.1 });
    this.mesh = new THREE.Mesh(geometry, material);
    this.mesh.position.copy(spawnPosition);
    this.mesh.position.y = this.height / 2;
    this.mesh.castShadow = true;
  }

  /** Interactables currently in the world that the player might reach. In
   *  Phase 1 the prototype area registers its own props directly; a full
   *  spatial index arrives once districts have real content density. */
  setInteractionCandidates(candidates: IInteractable[]): void {
    this.interactionCandidates = candidates;
  }

  get currentInteractable(): IInteractable | null {
    return this.nearestInteractable;
  }

  update(dt: number): void {
    this.handleLook();
    this.handleCrouch(dt);
    this.handleMovement(dt);
    this.handleStamina(dt);
    this.updateInteraction();

    if (this.input.wasJustPressed(InputAction.Interact)) {
      this.nearestInteractable?.interact();
    }
  }

  private handleLook(): void {
    if (!this.input.isPointerLocked) return;
    const delta = this.input.consumeMouseDelta();
    this.camera.applyLookDelta(delta.x * MOUSE_SENSITIVITY, delta.y * MOUSE_SENSITIVITY);
  }

  private handleCrouch(dt: number): void {
    this.crouching = this.input.isActionDown(InputAction.Crouch);
    const targetHeight = this.crouching ? CROUCH_HEIGHT : STAND_HEIGHT;
    this.height = THREE.MathUtils.damp(this.height, targetHeight, 10, dt);
    this.mesh.scale.y = this.height / STAND_HEIGHT;
  }

  private handleMovement(dt: number): void {
    const forward = this.input.isActionDown(InputAction.MoveForward) ? 1 : 0;
    const back = this.input.isActionDown(InputAction.MoveBack) ? 1 : 0;
    const left = this.input.isActionDown(InputAction.MoveLeft) ? 1 : 0;
    const right = this.input.isActionDown(InputAction.MoveRight) ? 1 : 0;

    const moveVector = new THREE.Vector3(right - left, 0, back - forward);
    const hasInput = moveVector.lengthSq() > 0;
    if (hasInput) moveVector.normalize();

    const yaw = this.camera.orbitYaw;
    moveVector.applyAxisAngle(new THREE.Vector3(0, 1, 0), yaw);

    const sprinting = this.input.isActionDown(InputAction.Sprint) && !this.crouching && this.stamina > 0;
    const speed = this.crouching ? CROUCH_SPEED : sprinting ? SPRINT_SPEED : WALK_SPEED;

    this.mesh.position.x += moveVector.x * speed * dt;
    this.mesh.position.z += moveVector.z * speed * dt;

    if (hasInput) {
      const targetRotation = Math.atan2(moveVector.x, moveVector.z);
      this.mesh.rotation.y = THREE.MathUtils.damp(this.mesh.rotation.y, targetRotation, 12, dt);
    }

    // Ground plane approximation (y = 0). Replaced by real ground raycast
    // once district collision meshes exist.
    if (this.grounded && this.input.wasJustPressed(InputAction.Jump)) {
      this.velocityY = JUMP_SPEED;
      this.grounded = false;
    }

    this.velocityY += GRAVITY * dt;
    this.mesh.position.y += this.velocityY * dt;

    const groundY = this.height / 2;
    if (this.mesh.position.y <= groundY) {
      this.mesh.position.y = groundY;
      this.velocityY = 0;
      this.grounded = true;
    }

    this.input.consumeJustPressed();
  }

  private handleStamina(dt: number): void {
    const sprinting = this.input.isActionDown(InputAction.Sprint) && !this.crouching;
    const moving = this.input.isActionDown(InputAction.MoveForward) || this.input.isActionDown(InputAction.MoveBack) ||
      this.input.isActionDown(InputAction.MoveLeft) || this.input.isActionDown(InputAction.MoveRight);

    if (sprinting && moving) {
      this.stamina = Math.max(0, this.stamina - STAMINA_DRAIN_PER_SEC * dt);
    } else {
      this.stamina = Math.min(STAMINA_MAX, this.stamina + STAMINA_REGEN_PER_SEC * dt);
    }
  }

  private updateInteraction(): void {
    let nearest: IInteractable | null = null;
    let nearestDist = INTERACT_RANGE;

    for (const candidate of this.interactionCandidates) {
      if (!candidate.canInteract()) continue;
      const dist = this.mesh.position.distanceTo(candidate.object3D.position);
      if (dist < nearestDist) {
        nearestDist = dist;
        nearest = candidate;
      }
    }

    this.nearestInteractable = nearest;
  }
}
