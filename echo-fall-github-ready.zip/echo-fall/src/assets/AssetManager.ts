import * as THREE from 'three';
import { GLTFLoader, type GLTF } from 'three/addons/loaders/GLTFLoader.js';
import { DRACOLoader } from 'three/addons/loaders/DRACOLoader.js';
import { Logger } from '../core/Logger';

const log = Logger.create('AssetManager');

export type LoadProgressHandler = (loaded: number, total: number) => void;

/**
 * Central GLTF/GLB loading + caching (Section 2 / 26). Assets are lazy
 * loaded on demand (never all up-front at startup) and cached by URL so
 * repeated instantiation (e.g. spawning the same prop many times) doesn't
 * re-fetch or re-parse the file.
 */
export class AssetManager {
  private gltfLoader: GLTFLoader;
  private cache = new Map<string, Promise<GLTF>>();

  constructor(dracoDecoderPath = '/draco/') {
    const dracoLoader = new DRACOLoader();
    dracoLoader.setDecoderPath(dracoDecoderPath);

    this.gltfLoader = new GLTFLoader();
    this.gltfLoader.setDRACOLoader(dracoLoader);
  }

  /** Load (or return cached) GLTF for a URL. Safe to call multiple times. */
  loadGLTF(url: string, onProgress?: LoadProgressHandler): Promise<GLTF> {
    const cached = this.cache.get(url);
    if (cached) return cached;

    const promise = new Promise<GLTF>((resolve, reject) => {
      this.gltfLoader.load(
        url,
        (gltf) => resolve(gltf),
        (evt) => {
          if (onProgress && evt.total > 0) onProgress(evt.loaded, evt.total);
        },
        (err) => {
          log.error(`Failed to load GLTF "${url}"`, err);
          this.cache.delete(url);
          reject(err instanceof Error ? err : new Error(String(err)));
        }
      );
    });

    this.cache.set(url, promise);
    return promise;
  }

  /** Instantiate a fresh, independently-transformable clone of a cached asset. */
  async instantiate(url: string): Promise<THREE.Object3D> {
    const gltf = await this.loadGLTF(url);
    return gltf.scene.clone(true);
  }

  /** Drop a cached asset (e.g. a district was unloaded and its props with it). */
  unload(url: string): void {
    this.cache.delete(url);
  }

  clear(): void {
    this.cache.clear();
  }
}
