import './style.css';
import { Game } from './game/Game';

function showFatalHtml(message: string): void {
  const errorScreen = document.getElementById('screen-error');
  const errorMessage = document.getElementById('error-message');
  if (errorScreen && errorMessage) {
    errorMessage.textContent = message;
    errorScreen.hidden = false;
  } else {
    // Absolute last resort if the DOM itself failed to build.
    document.body.innerHTML = `<div style="padding:40px;color:#fff;font-family:sans-serif;">
      <h2>ECHO//FALL failed to load</h2><p>${message}</p>
      <button onclick="location.reload()">Reload</button></div>`;
  }
}

window.addEventListener('unhandledrejection', (e) => {
  console.error('[main] Unhandled rejection', e.reason);
});
window.addEventListener('error', (e) => {
  console.error('[main] Uncaught error', e.error ?? e.message);
});

const game = new Game();
game.bootstrap().catch((err) => {
  console.error('[main] Bootstrap failed', err);
  showFatalHtml(err instanceof Error ? err.message : 'Unknown startup error.');
});
