export interface PerfStats {
  fps: number;
  frameMs: number;
  avgFrameMs: number;
}

/**
 * Tracks frame timing so quality-scaling decisions (Section 33) and any
 * future debug overlay have real numbers to work from, without adding
 * meaningful per-frame overhead itself.
 */
export class PerformanceMonitor {
  private samples: number[] = [];
  private readonly maxSamples = 90;
  private listeners = new Set<(stats: PerfStats) => void>();

  recordFrame(frameDt: number): PerfStats {
    const frameMs = frameDt * 1000;
    this.samples.push(frameMs);
    if (this.samples.length > this.maxSamples) this.samples.shift();

    const avgFrameMs = this.samples.reduce((a, b) => a + b, 0) / this.samples.length;
    const stats: PerfStats = {
      fps: frameMs > 0 ? 1000 / frameMs : 0,
      frameMs,
      avgFrameMs
    };

    for (const listener of this.listeners) listener(stats);
    return stats;
  }

  onSample(listener: (stats: PerfStats) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }
}
