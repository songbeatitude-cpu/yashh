import type * as THREE from 'three';

/** Rendering backend actually selected at runtime. */
export type RendererBackend = 'webgpu' | 'webgl2';

/** Graphics quality tiers (Section 33). Phase 1 wires the enum + settings
 *  storage; per-tier visual behavior (shadows, draw distance, etc.) is
 *  layered on in later phases as those systems are built. */
export enum Quality {
  Low = 'low',
  Medium = 'medium',
  High = 'high',
  Ultra = 'ultra'
}

/** Input actions, decoupled from physical keys so rebinding / future
 *  gamepad support doesn't touch gameplay code. */
export enum InputAction {
  MoveForward = 'moveForward',
  MoveBack = 'moveBack',
  MoveLeft = 'moveLeft',
  MoveRight = 'moveRight',
  Sprint = 'sprint',
  Crouch = 'crouch',
  Jump = 'jump',
  Interact = 'interact',
  Echo = 'echo',
  Pause = 'pause'
}

/**
 * World event names (Section 11). Declaring the full vocabulary now keeps
 * every future system's payloads type-checked against one source of truth,
 * even though Phase 1 only ever emits a handful of these.
 */
export enum GameEvent {
  PlayerEnteredLocation = 'PLAYER_ENTERED_LOCATION',
  NpcHelped = 'NPC_HELPED',
  NpcAttacked = 'NPC_ATTACKED',
  NpcKilled = 'NPC_KILLED',
  ItemStolen = 'ITEM_STOLEN',
  PlayerDiscoveredClue = 'PLAYER_DISCOVERED_CLUE',
  PlayerUsedEcho = 'PLAYER_USED_ECHO',
  MissionCompleted = 'MISSION_COMPLETED',
  MissionFailed = 'MISSION_FAILED',
  FactionAlerted = 'FACTION_ALERTED',
  WorldStateChanged = 'WORLD_STATE_CHANGED',

  // Engine/application-level events used by Phase 1 plumbing.
  RendererReady = 'RENDERER_READY',
  GameLoaded = 'GAME_LOADED',
  GamePaused = 'GAME_PAUSED',
  GameResumed = 'GAME_RESUMED',
  SettingsChanged = 'SETTINGS_CHANGED',
  SaveCompleted = 'SAVE_COMPLETED',
  LoadCompleted = 'LOAD_COMPLETED',
  FatalError = 'FATAL_ERROR'
}

/** Payload map: every event above must appear here (possibly as void). */
export interface GameEventMap {
  [GameEvent.PlayerEnteredLocation]: { locationId: string };
  [GameEvent.NpcHelped]: { npcId: string };
  [GameEvent.NpcAttacked]: { npcId: string; attackerId: string };
  [GameEvent.NpcKilled]: { npcId: string; killerId: string };
  [GameEvent.ItemStolen]: { itemId: string; fromNpcId?: string };
  [GameEvent.PlayerDiscoveredClue]: { clueId: string };
  [GameEvent.PlayerUsedEcho]: { anchorId: string };
  [GameEvent.MissionCompleted]: { missionId: string };
  [GameEvent.MissionFailed]: { missionId: string; reason?: string };
  [GameEvent.FactionAlerted]: { factionId: string; reason?: string };
  [GameEvent.WorldStateChanged]: { key: string };

  [GameEvent.RendererReady]: { backend: RendererBackend };
  [GameEvent.GameLoaded]: void;
  [GameEvent.GamePaused]: void;
  [GameEvent.GameResumed]: void;
  [GameEvent.SettingsChanged]: { quality: Quality };
  [GameEvent.SaveCompleted]: { slot: string };
  [GameEvent.LoadCompleted]: { slot: string };
  [GameEvent.FatalError]: { message: string; error?: unknown };
}

/**
 * Anything the player can raycast-interact with (Section 10). NPCs, doors,
 * clues, Echo anchors etc. all implement this rather than the interaction
 * system knowing about each concrete type.
 */
export interface IInteractable {
  readonly interactionId: string;
  readonly interactionPrompt: string;
  readonly object3D: THREE.Object3D;
  canInteract(): boolean;
  interact(): void;
}

/** Serializable save payload. Grows as new systems add state. */
export interface SaveData {
  version: number;
  savedAt: number;
  world: Record<string, unknown>;
  player: {
    position: [number, number, number];
    yaw: number;
  };
  settings: {
    quality: Quality;
  };
}
