import { EventBus } from '../core/EventBus';
import { GameEvent, Quality, type RendererBackend } from '../types';
import { Logger } from '../core/Logger';

const log = Logger.create('SettingsManager');
const STORAGE_KEY = 'echo-fall:settings';

export interface Settings {
  quality: Quality;
  masterVolume: number; // 0..1
}

const DEFAULT_SETTINGS: Settings = {
  quality: Quality.Medium,
  masterVolume: 0.8
};

/**
 * Small config/preferences → localStorage (Section 2/29), distinct from
 * SaveManager's IndexedDB-backed game progress. Also picks a sensible
 * default quality tier from basic hardware signals (Section 33).
 */
export class SettingsManager {
  private settings: Settings;

  constructor(private readonly events: EventBus, backend?: RendererBackend) {
    this.settings = this.load() ?? SettingsManager.recommendDefaults(backend);
  }

  static recommendDefaults(backend?: RendererBackend): Settings {
    const cores = navigator.hardwareConcurrency ?? 4;
    const dpr = window.devicePixelRatio ?? 1;

    let quality = Quality.Medium;
    if (backend === 'webgpu' && cores >= 8) quality = Quality.High;
    else if (cores <= 2 || dpr > 2.5) quality = Quality.Low;

    return { ...DEFAULT_SETTINGS, quality };
  }

  get(): Readonly<Settings> {
    return this.settings;
  }

  setQuality(quality: Quality): void {
    this.settings.quality = quality;
    this.persist();
    this.events.emit(GameEvent.SettingsChanged, { quality });
  }

  setMasterVolume(volume01: number): void {
    this.settings.masterVolume = Math.min(1, Math.max(0, volume01));
    this.persist();
  }

  private load(): Settings | null {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw);
      return { ...DEFAULT_SETTINGS, ...parsed };
    } catch (err) {
      log.warn('Could not read stored settings, using defaults.', err);
      return null;
    }
  }

  private persist(): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.settings));
    } catch (err) {
      log.warn('Could not persist settings (storage full or unavailable).', err);
    }
  }
}
