import * as THREE from 'three';
import type { District } from '../render/SceneManager';
import type { IInteractable } from '../types';

/**
 * PROTOTYPE_AREA — Phase 1 only.
 *
 * This is explicitly NOT the full DISTRICT_01 described in Section 7 (main
 * street, alley, shop, combat encounter, stealth opportunity, Echo
 * investigation, etc.). Building that out is later-phase content work.
 * What this proves right now is the plumbing: a District can be loaded
 * into the SceneManager, procedurally built, lit, and it registers a real
 * IInteractable so the interaction system has something genuine to hit.
 */
export class PrototypeArea implements District {
  readonly id = 'PROTOTYPE_AREA';
  private group = new THREE.Group();
  private beacon: IInteractable | null = null;

  async load(scene: THREE.Scene): Promise<void> {
    scene.background = new THREE.Color(0x0a1014);
    scene.fog = new THREE.FogExp2(0x0a1014, 0.018);

    const hemi = new THREE.HemisphereLight(0x9fd8ff, 0x1a1f22, 0.6);
    const sun = new THREE.DirectionalLight(0xffe8c8, 1.1);
    sun.position.set(20, 30, 10);
    sun.castShadow = true;
    sun.shadow.mapSize.set(1024, 1024);
    this.group.add(hemi, sun);

    const ground = new THREE.Mesh(
      new THREE.PlaneGeometry(120, 120),
      new THREE.MeshStandardMaterial({ color: 0x1c2226, roughness: 0.95 })
    );
    ground.rotation.x = -Math.PI / 2;
    ground.receiveShadow = true;
    this.group.add(ground);

    // A handful of ruined-tower silhouettes so there's something to orient
    // against and to demonstrate instancing for repeated geometry.
    const towerGeo = new THREE.BoxGeometry(4, 1, 4);
    const towerMat = new THREE.MeshStandardMaterial({ color: 0x2a3339, roughness: 0.8, metalness: 0.2 });
    const towerCount = 24;
    const towers = new THREE.InstancedMesh(towerGeo, towerMat, towerCount);
    towers.castShadow = true;
    towers.receiveShadow = true;

    const dummy = new THREE.Object3D();
    let i = 0;
    for (let ring = 0; ring < 3; ring++) {
      const radius = 18 + ring * 14;
      const count = 6 + ring * 2;
      for (let n = 0; n < count && i < towerCount; n++, i++) {
        const angle = (n / count) * Math.PI * 2;
        const height = 8 + Math.random() * 20;
        dummy.position.set(Math.cos(angle) * radius, height / 2, Math.sin(angle) * radius);
        dummy.scale.set(1 + Math.random(), height, 1 + Math.random());
        dummy.updateMatrix();
        towers.setMatrixAt(i, dummy.matrix);
      }
    }
    this.group.add(towers);

    // A single Echo-anchor beacon: real IInteractable, not a stub graphic.
    const beaconMesh = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.5),
      new THREE.MeshStandardMaterial({ color: 0x4ee6c8, emissive: 0x1f5a50, emissiveIntensity: 1.2 })
    );
    beaconMesh.position.set(4, 1, -4);
    this.group.add(beaconMesh);

    this.beacon = {
      interactionId: 'echo-anchor-proto-01',
      interactionPrompt: 'Press E to focus ECHO',
      object3D: beaconMesh,
      canInteract: () => true,
      interact: () => {
        // The full historical-reconstruction ECHO system (Section 18/19) is
        // later-phase work. Phase 1 proves the interaction hits real
        // world objects; here we just visibly acknowledge the trigger.
        beaconMesh.scale.setScalar(1.4);
        setTimeout(() => beaconMesh.scale.setScalar(1), 250);
      }
    };

    scene.add(this.group);
  }

  unload(scene: THREE.Scene): void {
    scene.remove(this.group);
    this.group.traverse((obj) => {
      if (obj instanceof THREE.Mesh) {
        obj.geometry.dispose();
        const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
        mats.forEach((m) => m.dispose());
      }
    });
    scene.background = null;
    scene.fog = null;
  }

  update(_dt: number): void {
    // No per-frame simulation needed yet — Phase 2+ NPC/AI systems hook in here.
  }

  getInteractables(): IInteractable[] {
    return this.beacon ? [this.beacon] : [];
  }
}
