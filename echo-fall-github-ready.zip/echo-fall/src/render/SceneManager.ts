import * as THREE from 'three';
import { Logger } from '../core/Logger';

const log = Logger.create('SceneManager');

/**
 * A loadable chunk of the world (Section 6: CITY -> DISTRICT_01, DISTRICT_02,
 * UNDERCITY, ZENITH, ...). Only the active district's content should be
 * resident in the THREE.Scene at once. Phase 1 ships the interface and a
 * single prototype district; district streaming/unloading of *multiple*
 * simultaneous districts is a later-phase concern once there is more than
 * one district to stream.
 */
export interface District {
  readonly id: string;
  /** Populate `scene` with this district's content. May be async (asset loads). */
  load(scene: THREE.Scene): Promise<void>;
  /** Tear down everything this district added, freeing GPU resources. */
  unload(scene: THREE.Scene): void;
  /** Per fixed-tick update while this district is active. */
  update(dt: number): void;
}

export class SceneManager {
  readonly scene = new THREE.Scene();
  private activeDistrict: District | null = null;

  async loadDistrict(district: District): Promise<void> {
    if (this.activeDistrict) {
      log.info(`Unloading district "${this.activeDistrict.id}".`);
      this.activeDistrict.unload(this.scene);
    }
    log.info(`Loading district "${district.id}".`);
    await district.load(this.scene);
    this.activeDistrict = district;
  }

  update(dt: number): void {
    this.activeDistrict?.update(dt);
  }

  get current(): District | null {
    return this.activeDistrict;
  }
}
