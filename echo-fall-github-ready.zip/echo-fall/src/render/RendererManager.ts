import * as THREE from 'three';
import type { RendererBackend } from '../types';
import { Logger } from '../core/Logger';

const log = Logger.create('RendererManager');

/**
 * Common surface both THREE.WebGLRenderer and THREE.WebGPURenderer expose
 * that the rest of the engine actually needs. Keeping this narrow means the
 * rest of the codebase never has to branch on backend.
 */
export interface CompatibleRenderer {
  domElement: HTMLCanvasElement;
  setSize(width: number, height: number, updateStyle?: boolean): void;
  setPixelRatio(ratio: number): void;
  render(scene: THREE.Scene, camera: THREE.Camera): void;
  dispose(): void;
}

export interface RendererInitResult {
  renderer: CompatibleRenderer;
  backend: RendererBackend;
}

/**
 * Section 1 / 2 / 34: rendering architecture must detect capability at
 * startup, prefer WebGPU, and gracefully fall back to WebGL2 — never a
 * blank page.
 */
export class RendererManager {
  static async create(canvas: HTMLCanvasElement): Promise<RendererInitResult> {
    if (await RendererManager.webGPUAvailable()) {
      try {
        const backend = await RendererManager.createWebGPU(canvas);
        log.info('Using WebGPU renderer.');
        return backend;
      } catch (err) {
        log.warn('WebGPU renderer failed to initialize, falling back to WebGL2.', err);
      }
    } else {
      log.info('WebGPU not available in this browser, using WebGL2.');
    }

    return RendererManager.createWebGL2(canvas);
  }

  private static async webGPUAvailable(): Promise<boolean> {
    const gpu = (navigator as Navigator & { gpu?: any }).gpu;
    if (!gpu) return false;
    try {
      const adapter = await gpu.requestAdapter();
      return !!adapter;
    } catch {
      return false;
    }
  }

  private static async createWebGPU(canvas: HTMLCanvasElement): Promise<RendererInitResult> {
    // Dynamic import: keeps the WebGPU build out of the WebGL-only bundle
    // path and lets this fail cleanly on browsers/builds without it.
    const { WebGPURenderer } = await import('three/webgpu');
    const renderer = new WebGPURenderer({
      canvas,
      antialias: true,
      powerPreference: 'high-performance'
    });
    await renderer.init();
    return { renderer: renderer as unknown as CompatibleRenderer, backend: 'webgpu' };
  }

  private static createWebGL2(canvas: HTMLCanvasElement): RendererInitResult {
    if (!RendererManager.webGL2Available(canvas)) {
      throw new Error('Neither WebGPU nor WebGL2 is available in this browser.');
    }
    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      powerPreference: 'high-performance'
    });
    renderer.setClearColor(0x05070a, 1);
    return { renderer, backend: 'webgl2' };
  }

  private static webGL2Available(canvas: HTMLCanvasElement): boolean {
    try {
      const probe = canvas.getContext('webgl2');
      return !!probe;
    } catch {
      return false;
    }
  }
}
