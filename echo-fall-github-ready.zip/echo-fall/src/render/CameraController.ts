import * as THREE from 'three';

export interface CameraControllerOptions {
  distance?: number;
  height?: number;
  followSmoothing?: number; // 0..1, higher = snappier
  lookSmoothing?: number;
  minPitch?: number;
  maxPitch?: number;
}

/**
 * Cinematic third-person camera (Section 9). Deliberately owns all camera
 * behavior itself rather than living inside the player class, so cinematic
 * cameras / Echo playback cameras / aim-mode can reuse or replace it later
 * without touching player movement code.
 *
 * Phase 1 implements: smooth positional/look-at follow, mouse-driven
 * orbit (yaw/pitch), configurable distance & height, and a shake system.
 * Collision avoidance (camera pulled in by geometry) is stubbed with a
 * clear extension point — Phase 1 has no district geometry dense enough to
 * require it yet.
 */
export class CameraController {
  readonly camera: THREE.PerspectiveCamera;

  private distance: number;
  private height: number;
  private followSmoothing: number;
  private lookSmoothing: number;
  private minPitch: number;
  private maxPitch: number;

  private yaw = 0;
  private pitch = -0.15;

  private target = new THREE.Vector3();
  private currentPosition = new THREE.Vector3();
  private currentLookAt = new THREE.Vector3();

  private shakeTrauma = 0;
  private shakeSeed = Math.random() * 1000;

  constructor(aspect: number, options: CameraControllerOptions = {}) {
    this.camera = new THREE.PerspectiveCamera(60, aspect, 0.1, 500);
    this.distance = options.distance ?? 4.5;
    this.height = options.height ?? 1.7;
    this.followSmoothing = options.followSmoothing ?? 8;
    this.lookSmoothing = options.lookSmoothing ?? 10;
    this.minPitch = options.minPitch ?? -0.9;
    this.maxPitch = options.maxPitch ?? 1.2;
  }

  setAspect(aspect: number): void {
    this.camera.aspect = aspect;
    this.camera.updateProjectionMatrix();
  }

  /** Feed raw mouse-look delta (radians) from the input system. */
  applyLookDelta(deltaYaw: number, deltaPitch: number): void {
    this.yaw -= deltaYaw;
    this.pitch = THREE.MathUtils.clamp(this.pitch - deltaPitch, this.minPitch, this.maxPitch);
  }

  get orbitYaw(): number {
    return this.yaw;
  }

  /** Trigger camera shake, e.g. on combat impact or explosions. */
  addShake(amount: number): void {
    this.shakeTrauma = THREE.MathUtils.clamp(this.shakeTrauma + amount, 0, 1);
  }

  /** Follow a target position (typically the player's head/pivot point). */
  update(targetPosition: THREE.Vector3, dt: number): void {
    this.target.copy(targetPosition);

    const offset = new THREE.Vector3(
      Math.sin(this.yaw) * Math.cos(this.pitch),
      Math.sin(this.pitch),
      Math.cos(this.yaw) * Math.cos(this.pitch)
    ).multiplyScalar(this.distance);

    const desiredPosition = this.target.clone().add(offset).add(new THREE.Vector3(0, this.height * 0.3, 0));
    const desiredLookAt = this.target.clone().add(new THREE.Vector3(0, this.height * 0.5, 0));

    const posT = 1 - Math.exp(-this.followSmoothing * dt);
    const lookT = 1 - Math.exp(-this.lookSmoothing * dt);

    this.currentPosition.lerp(desiredPosition, posT);
    this.currentLookAt.lerp(desiredLookAt, lookT);

    this.applyShake(dt);

    this.camera.position.copy(this.currentPosition);
    this.camera.lookAt(this.currentLookAt);
  }

  /** Extension point: raycast from target toward desired camera position and
   *  pull the camera in if it would clip through geometry. Wired up once
   *  district collision meshes exist. */
  resolveCollision(_scene: THREE.Scene): void {
    // Intentionally left as a documented no-op in Phase 1.
  }

  snapTo(position: THREE.Vector3): void {
    this.currentPosition.copy(position);
    this.currentLookAt.copy(position);
  }

  private applyShake(dt: number): void {
    if (this.shakeTrauma <= 0) return;
    this.shakeSeed += dt * 30;
    const strength = this.shakeTrauma * this.shakeTrauma;
    const offsetX = (Math.sin(this.shakeSeed * 1.3) - 0.5) * 0.1 * strength;
    const offsetY = (Math.cos(this.shakeSeed * 1.7) - 0.5) * 0.1 * strength;
    this.currentPosition.x += offsetX;
    this.currentPosition.y += offsetY;
    this.shakeTrauma = Math.max(0, this.shakeTrauma - dt * 1.2);
  }
}
