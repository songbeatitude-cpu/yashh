export class LoadingScreen {
  private bar = document.getElementById('loading-bar') as HTMLElement;
  private status = document.getElementById('loading-status') as HTMLElement;

  setProgress(fraction: number, statusText?: string): void {
    this.bar.style.width = `${Math.round(Math.min(1, Math.max(0, fraction)) * 100)}%`;
    if (statusText) this.status.textContent = statusText;
  }

  reset(): void {
    this.setProgress(0, 'Initializing…');
  }
}
