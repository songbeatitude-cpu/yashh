export interface PauseMenuCallbacks {
  onResume: () => void;
  onSave: () => void;
  onSettings: () => void;
  onQuit: () => void;
}

export class PauseMenu {
  private resumeBtn = document.getElementById('btn-resume') as HTMLButtonElement;
  private saveBtn = document.getElementById('btn-save') as HTMLButtonElement;
  private settingsBtn = document.getElementById('btn-pause-settings') as HTMLButtonElement;
  private quitBtn = document.getElementById('btn-quit') as HTMLButtonElement;

  constructor(callbacks: PauseMenuCallbacks) {
    this.resumeBtn.addEventListener('click', callbacks.onResume);
    this.saveBtn.addEventListener('click', callbacks.onSave);
    this.settingsBtn.addEventListener('click', callbacks.onSettings);
    this.quitBtn.addEventListener('click', callbacks.onQuit);
  }
}
