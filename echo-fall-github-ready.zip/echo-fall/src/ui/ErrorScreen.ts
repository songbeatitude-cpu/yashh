export class ErrorScreen {
  private messageEl = document.getElementById('error-message') as HTMLElement;
  private reloadBtn = document.getElementById('btn-error-reload') as HTMLButtonElement;

  constructor() {
    this.reloadBtn.addEventListener('click', () => window.location.reload());
  }

  setMessage(message: string): void {
    this.messageEl.textContent = message;
  }
}
