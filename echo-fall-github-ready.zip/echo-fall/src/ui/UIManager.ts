export type ScreenId =
  | 'main-menu'
  | 'loading'
  | 'error'
  | 'pause'
  | 'settings'
  | 'hud';

/**
 * Section 27/28: the website chrome (landing screen, loading screen, pause
 * menu, settings, HUD) lives as DOM overlays above the WebGL/WebGPU canvas.
 * UIManager just toggles visibility; each screen's own interactive wiring
 * lives in its own small class so this file doesn't grow into a monolith.
 */
export class UIManager {
  private screens: Record<ScreenId, HTMLElement>;

  constructor() {
    this.screens = {
      'main-menu': this.require('screen-main-menu'),
      loading: this.require('screen-loading'),
      error: this.require('screen-error'),
      pause: this.require('screen-pause'),
      settings: this.require('screen-settings'),
      hud: this.require('hud')
    };
  }

  private require(id: string): HTMLElement {
    const el = document.getElementById(id);
    if (!el) throw new Error(`UIManager: missing required DOM element #${id}`);
    return el;
  }

  show(id: ScreenId): void {
    this.screens[id].hidden = false;
  }

  hide(id: ScreenId): void {
    this.screens[id].hidden = true;
  }

  /** Show exactly one of the mutually-exclusive full-screen menus, hiding the rest. */
  showExclusive(id: Extract<ScreenId, 'main-menu' | 'loading' | 'error' | 'pause' | 'settings'>): void {
    (['main-menu', 'loading', 'error', 'pause', 'settings'] as const).forEach((s) => {
      this.screens[s].hidden = s !== id;
    });
  }

  hideAllMenus(): void {
    (['main-menu', 'loading', 'error', 'pause', 'settings'] as const).forEach((s) => {
      this.screens[s].hidden = true;
    });
  }
}
