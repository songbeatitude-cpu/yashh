import { Quality } from '../types';
import type { SettingsManager } from '../settings/SettingsManager';

export interface SettingsMenuCallbacks {
  onBack: () => void;
}

export class SettingsMenu {
  private qualitySelect = document.getElementById('setting-quality') as HTMLSelectElement;
  private volumeSlider = document.getElementById('setting-volume') as HTMLInputElement;
  private backBtn = document.getElementById('btn-settings-back') as HTMLButtonElement;

  constructor(private readonly settings: SettingsManager, callbacks: SettingsMenuCallbacks) {
    this.syncFromSettings();

    this.qualitySelect.addEventListener('change', () => {
      this.settings.setQuality(this.qualitySelect.value as Quality);
    });
    this.volumeSlider.addEventListener('input', () => {
      this.settings.setMasterVolume(Number(this.volumeSlider.value) / 100);
    });
    this.backBtn.addEventListener('click', callbacks.onBack);
  }

  syncFromSettings(): void {
    const current = this.settings.get();
    this.qualitySelect.value = current.quality;
    this.volumeSlider.value = String(Math.round(current.masterVolume * 100));
  }
}
