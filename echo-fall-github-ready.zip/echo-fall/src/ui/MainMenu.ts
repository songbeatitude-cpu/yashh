import type { RendererBackend } from '../types';

export interface MainMenuCallbacks {
  onPlay: () => void;
  onContinue: () => void;
  onSettings: () => void;
}

export class MainMenu {
  private playBtn = document.getElementById('btn-play') as HTMLButtonElement;
  private continueBtn = document.getElementById('btn-continue') as HTMLButtonElement;
  private settingsBtn = document.getElementById('btn-settings') as HTMLButtonElement;
  private rendererBadge = document.getElementById('renderer-badge') as HTMLElement;

  constructor(callbacks: MainMenuCallbacks) {
    this.playBtn.addEventListener('click', callbacks.onPlay);
    this.continueBtn.addEventListener('click', callbacks.onContinue);
    this.settingsBtn.addEventListener('click', callbacks.onSettings);
  }

  setHasSave(hasSave: boolean): void {
    this.continueBtn.hidden = !hasSave;
  }

  setRendererBackend(backend: RendererBackend): void {
    this.rendererBadge.textContent = backend === 'webgpu' ? 'WebGPU' : 'WebGL2';
  }
}
