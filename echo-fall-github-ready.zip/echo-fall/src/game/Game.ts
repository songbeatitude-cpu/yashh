import * as THREE from 'three';
import { EventBus } from '../core/EventBus';
import { GameLoop } from '../core/GameLoop';
import { Logger } from '../core/Logger';
import { RendererManager, type CompatibleRenderer } from '../render/RendererManager';
import { SceneManager } from '../render/SceneManager';
import { CameraController } from '../render/CameraController';
import { InputManager } from '../input/InputManager';
import { AssetManager } from '../assets/AssetManager';
import { WorldStateManager } from '../state/WorldStateManager';
import { SaveManager } from '../state/SaveManager';
import { SettingsManager } from '../settings/SettingsManager';
import { PerformanceMonitor } from '../perf/PerformanceMonitor';
import { PlayerController } from '../player/PlayerController';
import { UIManager } from '../ui/UIManager';
import { LoadingScreen } from '../ui/LoadingScreen';
import { ErrorScreen } from '../ui/ErrorScreen';
import { MainMenu } from '../ui/MainMenu';
import { PauseMenu } from '../ui/PauseMenu';
import { SettingsMenu } from '../ui/SettingsMenu';
import { PrototypeArea } from '../world/PrototypeArea';
import { GameEvent, type RendererBackend, type SaveData } from '../types';

const log = Logger.create('Game');
const SAVE_SLOT = 'default';

/**
 * Top-level orchestrator. Owns the lifecycle: boot -> main menu -> loading
 * -> playing -> pause -> save/quit. Deliberately thin — each concern
 * (rendering, input, state, UI) lives in its own class; this file wires
 * them together and reacts to menu actions.
 */
export class Game {
  private canvas = document.getElementById('game-canvas') as HTMLCanvasElement;

  readonly events = new EventBus();
  private ui = new UIManager();
  private loadingScreen = new LoadingScreen();
  private errorScreen = new ErrorScreen();
  private mainMenu!: MainMenu;
  private pauseMenu!: PauseMenu;
  private settingsMenu!: SettingsMenu;

  private compatRenderer!: CompatibleRenderer;
  private backend!: RendererBackend;
  private sceneManager = new SceneManager();
  private camera!: CameraController;
  private input!: InputManager;
  private assets = new AssetManager();
  private worldState!: WorldStateManager;
  private saveManager = new SaveManager();
  private settings!: SettingsManager;
  private perf = new PerformanceMonitor();
  private player!: PlayerController;
  private loop!: GameLoop;

  private currentDistrict: PrototypeArea | null = null;
  private isPaused = false;

  async bootstrap(): Promise<void> {
    try {
      const { renderer, backend } = await RendererManager.create(this.canvas);
      this.compatRenderer = renderer;
      this.backend = backend;
      this.events.emit(GameEvent.RendererReady, { backend });

      this.worldState = new WorldStateManager(this.events);
      this.settings = new SettingsManager(this.events, backend);
      this.camera = new CameraController(window.innerWidth / window.innerHeight);
      this.input = new InputManager(this.canvas);

      window.addEventListener('resize', this.onResize);
      this.onResize();

      this.mainMenu = new MainMenu({
        onPlay: () => void this.startNewGame(),
        onContinue: () => void this.continueGame(),
        onSettings: () => this.ui.showExclusive('settings')
      });
      this.mainMenu.setRendererBackend(backend);
      this.mainMenu.setHasSave(await this.saveManager.hasSave(SAVE_SLOT));

      this.pauseMenu = new PauseMenu({
        onResume: () => this.resume(),
        onSave: () => void this.saveGame(),
        onSettings: () => this.ui.showExclusive('settings'),
        onQuit: () => this.quitToMenu()
      });

      this.settingsMenu = new SettingsMenu(this.settings, {
        onBack: () => (this.isPaused ? this.ui.showExclusive('pause') : this.ui.showExclusive('main-menu'))
      });

      this.input.consumeJustPressed();
      window.addEventListener('keydown', this.onGlobalKeyDown);

      this.ui.showExclusive('main-menu');
      log.info(`Bootstrapped successfully on ${backend}.`);
    } catch (err) {
      this.fail(err);
    }
  }

  private onGlobalKeyDown = (e: KeyboardEvent): void => {
    if (e.code === 'Escape' && this.loop?.isRunning) {
      this.isPaused ? this.resume() : this.pause();
    }
  };

  private async startNewGame(): Promise<void> {
    this.worldState.reset();
    await this.enterWorld();
  }

  private async continueGame(): Promise<void> {
    try {
      const data = await this.saveManager.load(SAVE_SLOT);
      if (!data) {
        await this.startNewGame();
        return;
      }
      this.worldState.deserialize(data.world);
      await this.enterWorld(data);
      this.events.emit(GameEvent.LoadCompleted, { slot: SAVE_SLOT });
    } catch (err) {
      this.fail(err);
    }
  }

  private async enterWorld(saveData?: SaveData): Promise<void> {
    this.ui.showExclusive('loading');
    this.loadingScreen.reset();

    try {
      this.loadingScreen.setProgress(0.15, 'Building world…');
      const district = new PrototypeArea();
      await this.sceneManager.loadDistrict(district);
      this.currentDistrict = district;

      this.loadingScreen.setProgress(0.6, 'Placing player…');
      const spawn = saveData
        ? new THREE.Vector3(...saveData.player.position)
        : new THREE.Vector3(0, 0, 6);
      this.player = new PlayerController(this.input, this.camera, spawn);
      this.sceneManager.scene.add(this.player.mesh);
      this.player.setInteractionCandidates(district.getInteractables());

      this.loadingScreen.setProgress(0.9, 'Starting simulation…');
      if (!this.loop) {
        this.loop = new GameLoop(this.fixedUpdate, this.render);
      }

      this.loadingScreen.setProgress(1, 'Ready.');
      this.ui.hideAllMenus();
      this.ui.show('hud');
      this.isPaused = false;
      this.loop.start();
      this.input.requestPointerLock();

      this.events.emit(GameEvent.GameLoaded, undefined);
      this.events.emit(GameEvent.PlayerEnteredLocation, { locationId: district.id });
    } catch (err) {
      this.fail(err);
    }
  }

  private fixedUpdate = (dt: number): void => {
    if (this.isPaused) return;
    this.player.update(dt);
    this.sceneManager.update(dt);

    const interactPrompt = document.getElementById('interact-prompt') as HTMLElement;
    const target = this.player.currentInteractable;
    interactPrompt.hidden = !target;
    if (target) interactPrompt.textContent = target.interactionPrompt;
  };

  private render = (_alpha: number, frameDt: number): void => {
    if (!this.isPaused) {
      this.camera.update(this.player.mesh.position, frameDt);
    }
    this.compatRenderer.render(this.sceneManager.scene, this.camera.camera);
    this.perf.recordFrame(frameDt);
  };

  private pause(): void {
    this.isPaused = true;
    this.input.exitPointerLock();
    this.ui.hide('hud');
    this.ui.showExclusive('pause');
    this.events.emit(GameEvent.GamePaused, undefined);
  }

  private resume(): void {
    this.isPaused = false;
    this.ui.hideAllMenus();
    this.ui.show('hud');
    this.input.requestPointerLock();
    this.events.emit(GameEvent.GameResumed, undefined);
  }

  private quitToMenu(): void {
    this.loop.stop();
    this.input.exitPointerLock();
    if (this.currentDistrict) this.currentDistrict.unload(this.sceneManager.scene);
    this.ui.hideAllMenus();
    this.ui.showExclusive('main-menu');
  }

  private async saveGame(): Promise<void> {
    try {
      const data: SaveData = {
        version: 1,
        savedAt: Date.now(),
        world: this.worldState.serialize(),
        player: {
          position: this.player.mesh.position.toArray() as [number, number, number],
          yaw: this.camera.orbitYaw
        },
        settings: { quality: this.settings.get().quality }
      };
      await this.saveManager.save(SAVE_SLOT, data);
      this.events.emit(GameEvent.SaveCompleted, { slot: SAVE_SLOT });
      this.mainMenu.setHasSave(true);
    } catch (err) {
      log.error('Save failed', err);
    }
  }

  private onResize = (): void => {
    const width = window.innerWidth;
    const height = window.innerHeight;
    this.compatRenderer.setSize(width, height);
    this.compatRenderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.camera.setAspect(width / height);
  };

  private fail(err: unknown): void {
    log.error('Fatal error', err);
    this.events.emit(GameEvent.FatalError, { message: String(err), error: err });
    this.errorScreen.setMessage(
      err instanceof Error ? err.message : 'An unexpected error occurred while loading ECHO//FALL.'
    );
    this.ui.showExclusive('error');
  }
}
