import { defineConfig } from 'vite';

// The website IS the game: single-page static build, deployable to any
// static host (Vercel / Netlify / Cloudflare Pages / GitHub Pages).
export default defineConfig({
  base: './',
  build: {
    outDir: 'dist',
    target: 'es2022',
    sourcemap: true,
    chunkSizeWarningLimit: 1500
  },
  server: {
    host: true,
    port: 5173
  },
  preview: {
    port: 4173
  }
});
