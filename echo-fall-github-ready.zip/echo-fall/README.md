# ECHO//FALL

[![CI](https://github.com/<your-username>/echo-fall/actions/workflows/ci.yml/badge.svg)](https://github.com/<your-username>/echo-fall/actions/workflows/ci.yml)
[![Deploy to GitHub Pages](https://github.com/<your-username>/echo-fall/actions/workflows/deploy.yml/badge.svg)](https://github.com/<your-username>/echo-fall/actions/workflows/deploy.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

A browser-first third-person 3D sci-fi mystery. **The website is the game** —
open the URL, click Play, you're in the 3D world. No engine editor, no
desktop client.

> **Status: Phase 1 — foundation.** This delivers the runnable
> browser-game skeleton (renderer, loop, camera, input, save/settings
> plumbing, full menu shell, one prototype area) per the project brief's
> Phase 1 scope. NPC memory/relationships, the ECHO historical-reconstruction
> system, missions, factions, combat and stealth are **not implemented
> yet** — they're later phases, built on top of this foundation.

## Quick start

```bash
npm install
npm run dev       # http://localhost:5173
```

```bash
npm run build      # production build -> dist/
npm run preview    # serve the production build locally
```

⚠️ **This code was written and reviewed in an offline sandbox with no
network access, so `npm install`/`npm run build` could not be executed or
verified during authoring.** The code follows the exact three.js /
Vite / TypeScript APIs for the pinned versions below, but please run the
commands above yourself and report back if anything doesn't build cleanly —
I'll fix it immediately.

## Tech stack

- TypeScript (strict mode)
- Three.js `^0.171.0` — `WebGPURenderer` (via `three/webgpu`) with automatic
  `WebGLRenderer` (WebGL2) fallback
- Vite `^5.4.11` — dev server + static production build
- No React in the render loop; UI chrome is plain DOM/CSS overlays

## Architecture

```
src/
  core/      EventBus (typed pub/sub for world events), GameLoop (fixed
             60Hz update + variable-rate render), Logger
  render/    RendererManager (WebGPU detect -> WebGL2 fallback),
             SceneManager (district load/unload), CameraController
             (cinematic third-person follow cam)
  input/     InputManager (action-based, rebindable, pointer-lock mouse-look)
  assets/    AssetManager (GLTF/GLB + Draco, cached, lazy-loaded)
  state/     WorldStateManager (in-memory, serializable world state),
             SaveManager (IndexedDB persistence)
  settings/  SettingsManager (quality tier + volume, localStorage)
  perf/      PerformanceMonitor (frame time / FPS tracking hooks)
  player/    PlayerController (WASD, sprint, crouch, jump, gravity, stamina,
             interaction raycasting via IInteractable)
  ui/        UIManager + MainMenu/LoadingScreen/ErrorScreen/PauseMenu/
             SettingsMenu — DOM overlays, not part of the 3D render loop
  world/     PrototypeArea — Phase 1 placeholder district proving the
             District/SceneManager streaming contract
  game/      Game.ts — orchestrates boot -> menu -> loading -> play -> pause
  types/     Shared enums/interfaces (GameEvent vocabulary, IInteractable,
             Quality, InputAction, SaveData)
```

**Design principles carried through every system:**
- Systems communicate through `EventBus`, not direct references, so later
  systems (NPC memory, factions, missions) can subscribe to
  `PLAYER_DISCOVERED_CLUE` etc. without today's code knowing they exist.
- Rendering is behind a narrow `CompatibleRenderer` interface so nothing
  outside `RendererManager` branches on WebGPU vs WebGL2.
- The world is loaded as discrete `District` objects (`SceneManager`), never
  as one giant always-resident scene — `PrototypeArea` is the first of what
  will become `DISTRICT_01`, `DISTRICT_02`, `UNDERCITY`, `ZENITH`, etc.
- Game progress → IndexedDB (`SaveManager`). Small preferences → localStorage
  (`SettingsManager`). These are intentionally not mixed.

## What actually works right now

- Landing screen → Play → loading screen → you're standing in a small
  procedural ruined-city prototype area, third-person camera following you.
- WASD movement, Shift sprint (drains/regens a stamina meter), Ctrl/C crouch,
  Space jump, mouse-look via pointer lock.
- Walking up to the glowing beacon shows an interact prompt; pressing E
  triggers a real `IInteractable.interact()` call (a visible pulse) — proof
  the interaction system reaches genuine world objects, not a mock.
- Esc pauses (releases pointer lock, shows Pause menu); Save writes real
  world/player state to IndexedDB; Continue on the main menu loads it back.
- Settings menu changes/persists graphics quality tier and volume.
- If WebGPU isn't available, or WebGPU init throws, or WebGL2 isn't
  available either, you get an explicit on-screen error — never a blank page.

## What's intentionally NOT here yet

Per the phased build plan, later phases add: full `DISTRICT_01` content
(street/alley/shop/underground entrance), NPC data model + memory +
relationships + AI simulation levels, the ECHO historical-reconstruction
system, mission framework, faction reputation, combat, stealth, positional
audio, and asset-format/LOD/texture-compression pipelines. The types and
event vocabulary for most of these already exist in `src/types/index.ts` so
those systems can be added without renegotiating the architecture.

## Pushing this to GitHub

1. Create a new empty repository on GitHub (don't initialize it with a
   README/license — this project already has both).
2. Replace every `<your-username>` placeholder in `package.json` and this
   README with your actual GitHub username (or repo owner/org).
3. From this project folder:
   ```bash
   git init
   git add .
   git commit -m "Initial commit: ECHO//FALL Phase 1"
   git branch -M main
   git remote add origin https://github.com/<your-username>/echo-fall.git
   git push -u origin main
   ```
4. In the repo's **Settings → Pages**, set "Source" to **GitHub Actions**.
   That's it — the included workflow (`.github/workflows/deploy.yml`) builds
   and deploys the game to `https://<your-username>.github.io/echo-fall/`
   automatically on every push to `main`, and can also be re-run manually
   from the **Actions** tab.
5. A separate workflow (`.github/workflows/ci.yml`) type-checks and builds
   the project on every push and pull request, so a broken build shows up
   as a red ✗ on the PR instead of on the deployed site.

## No-build quick demo

`web-demo/echo-fall.html` is a self-contained, single-file version of the
prototype area (Three.js loaded from a CDN, no npm install, no build step)
— useful for sharing a play-in-one-click link. The deploy workflow above
publishes it automatically at `https://<your-username>.github.io/echo-fall/play.html`
alongside the real build. It intentionally does not share code with the
`src/` project and won't get new features as the real game grows; treat it
as a lightweight standalone showcase, not something to build on.

## Deployment (without GitHub Pages)

`npm run build` produces static assets in `dist/` — deployable as-is to
Vercel, Netlify, Cloudflare Pages, or any static host, in addition to GitHub
Pages above. Serve over HTTPS in production; WebGPU requires a secure context.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md).

## License

[MIT](LICENSE) — see the LICENSE file. Change the copyright line there if
you want attribution under your own name instead.
