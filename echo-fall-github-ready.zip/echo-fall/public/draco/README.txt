Place the Draco WASM/JS decoder files here (draco_decoder.js, draco_decoder.wasm,
draco_wasm_wrapper.js) when you start shipping Draco-compressed GLB assets.
You can copy them from node_modules/three/examples/jsm/libs/draco/ after
`npm install`, or download them from the official Draco releases.

AssetManager.ts points DRACOLoader at "/draco/" by default.
