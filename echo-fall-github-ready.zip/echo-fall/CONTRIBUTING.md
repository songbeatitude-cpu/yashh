# Contributing to ECHO//FALL

This is an early-stage, single-vertical-slice project — see the "What's
intentionally NOT here yet" section of the README for the current scope.

## Local setup

```bash
npm install
npm run dev
```

## Before opening a PR

```bash
npm run typecheck
npm run build
```

Both must pass — the CI workflow (`.github/workflows/ci.yml`) runs the same
two commands on every push and pull request.

## Code style

- Strict TypeScript; avoid `any` outside genuinely dynamic boundaries.
- Systems talk to each other through `EventBus` (`src/core/EventBus.ts`),
  not direct references — see the architecture section of the README before
  adding a new system.
- No React or other framework in the render loop; UI chrome stays in
  `src/ui/` as plain DOM/CSS.
- Keep files scoped to one responsibility; prefer a new small file over
  growing an existing one into a monolith.

## Commit messages

Plain, descriptive, present tense (`Add stealth suspicion meter`, not
`Added stuff`). No strict convention enforced yet.
